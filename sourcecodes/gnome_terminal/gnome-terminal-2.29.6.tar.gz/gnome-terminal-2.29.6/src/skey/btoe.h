char *btoe(unsigned char *md);

